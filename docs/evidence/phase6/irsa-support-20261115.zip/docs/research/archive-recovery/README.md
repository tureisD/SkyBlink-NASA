# Reproduce the discovery incident

This folder contains a standard-library-only Python diagnostic. It makes seven
read-only requests, sequentially, without retries. It does not create async jobs
or alter SkyBlink. Output directories must be new so earlier failures survive.

From the repository root, run on each machine close in time:

```text
python docs/research/archive-recovery/probe.py --out archive-probe-network-a --timeout 20
```

Use `archive-probe-network-b` on the second machine. An exit code of 1 means at
least one minimal science query did not return a successful VOTable with rows;
the receipts explain whether it was an HTTP error, timeout or other result.
This diagnostic deliberately does not certify discovery completeness or images.
Responses are capped at 1 MiB; timeouts are socket-operation limits, not a hard
total wall-clock cap. Proxy values and credentials are not recorded.

Compare exact URLs, UTC request times, resolved addresses, HTTP status, response
hashes and XML query statuses. Different clients sharing the same network do not
provide the independent egress test. Send both receipt directories to the
maintainer; the [prepared IRSA incident](../../verification/irsa-incident-draft-2026-11-15.md)
contains the existing findings. It has not been sent.

The [execution report](../../verification/archive-recovery-execution-2026-11-15.md)
records the local result and the bounded cloud-index feasibility experiment.
